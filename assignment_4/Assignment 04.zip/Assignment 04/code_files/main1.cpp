#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <omp.h>

#include "init.h"
#include "utils.h"

// Global variables (must stay)
int GRID_X, GRID_Y, NX, NY;
int NUM_Points, Maxiter;
double dx, dy;

int main()
{
    int particle_counts[4] = {100, 10000, 1000000, 100000000};

    int configs[3][2] = {
        {250, 100},
        {500, 200},
        {1000, 400}
    };

    Maxiter = 10;

    for (int cfg = 0; cfg < 3; cfg++)
    {
        NX = configs[cfg][0];
        NY = configs[cfg][1];

        GRID_X = NX + 1;
        GRID_Y = NY + 1;

        dx = 1.0 / NX;
        dy = 1.0 / NY;

        printf("\nConfiguration %d: NX=%d NY=%d\n",
               cfg + 1, NX, NY);

        for (int pc = 0; pc < 5; pc++)
        {
            NUM_Points = particle_counts[pc];

            double *mesh_value =
                (double *)calloc(GRID_X * GRID_Y, sizeof(double));

            Points *points =
                (Points *)malloc(NUM_Points * sizeof(Points));

            double total_interp_time = 0.0;

            for (int iter = 0; iter < Maxiter; iter++)
            {
                initializepoints(points);

                clock_t start = clock();
                interpolation(mesh_value, points);
                clock_t end = clock();

                total_interp_time +=
                    (double)(end - start) / CLOCKS_PER_SEC;
            }

            printf("Points=%d  TotalInterpTime=%lf\n",
                   NUM_Points, total_interp_time);

            free(mesh_value);
            free(points);
        }
    }

    return 0;
}