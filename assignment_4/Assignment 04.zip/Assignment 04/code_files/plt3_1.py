import matplotlib.pyplot as plt
import numpy as np

iterations = np.arange(1,11)

# -------- LAB PARALLEL DATA (used for iteration curves) --------
lab_interp = [0.107031,0.106776,0.108828,0.108984,0.106823,0.107245,0.109601,0.108862,0.107254,0.109472]
lab_mover = [0.026004,0.026361,0.025743,0.026831,0.025892,0.026174,0.026210,0.026173,0.026260,0.026192]
lab_total = [0.133035,0.133137,0.134572,0.135815,0.132715,0.133419,0.135811,0.135035,0.133514,0.135664]

# -------- CLUSTER PARALLEL DATA --------
cluster_interp = [0.146789,0.168095,0.160403,0.157665,0.152567,0.159050,0.162709,0.165371,0.208880,0.197999]
cluster_mover = [0.086365,0.064827,0.064316,0.064300,0.064309,0.055590,0.053767,0.057070,0.057296,0.058277]
cluster_total = [0.233155,0.232922,0.224719,0.221964,0.216876,0.214640,0.216477,0.222440,0.266176,0.256276]


# LAB GRAPH
plt.figure(figsize=(8,5))
plt.plot(iterations, lab_interp, marker='o', label="Interpolation")
plt.plot(iterations, lab_mover, marker='s', label="Mover")
plt.plot(iterations, lab_total, marker='^', label="Total")

plt.xlabel("Iteration")
plt.ylabel("Execution Time (seconds)")
plt.title("Lab PC: Iteration vs Execution Time")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig("lab_iteration_times.png", dpi=300)
plt.close()


# CLUSTER GRAPH
plt.figure(figsize=(8,5))
plt.plot(iterations, cluster_interp, marker='o', label="Interpolation")
plt.plot(iterations, cluster_mover, marker='s', label="Mover")
plt.plot(iterations, cluster_total, marker='^', label="Total")

plt.xlabel("Iteration")
plt.ylabel("Execution Time (seconds)")
plt.title("HPC Cluster: Iteration vs Execution Time")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig("cluster_iteration_times.png", dpi=300)
plt.close()