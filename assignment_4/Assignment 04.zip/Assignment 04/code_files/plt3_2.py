import matplotlib.pyplot as plt
import numpy as np

# Serial mover times
lab_serial = [0.329618,0.333874,0.328261,0.332741,0.344608,0.326445,0.338068,0.347615,0.343665,0.324329]
cluster_serial = [0.256052,0.256377,0.255737,0.255913,0.255681,0.255780,0.258142,0.255668,0.255935,0.255824]

# Parallel mover times
lab_parallel = [0.026004,0.026361,0.025743,0.026831,0.025892,0.026174,0.026210,0.026173,0.026260,0.026192]
cluster_parallel = [0.086365,0.064827,0.064316,0.064300,0.064309,0.055590,0.053767,0.057070,0.057296,0.058277]

labels = ["Lab PC", "HPC Cluster"]

serial_avg = [np.mean(lab_serial), np.mean(cluster_serial)]
parallel_avg = [np.mean(lab_parallel), np.mean(cluster_parallel)]

x = np.arange(len(labels))
width = 0.35

plt.figure(figsize=(7,5))
plt.bar(x - width/2, serial_avg, width, label="Serial Mover")
plt.bar(x + width/2, parallel_avg, width, label="Parallel Mover")

plt.xticks(x, labels)
plt.ylabel("Average Execution Time (seconds)")
plt.title("Mover Serial vs Parallel Comparison")
plt.legend()
plt.grid(axis='y')

plt.tight_layout()
plt.savefig("mover_serial_vs_parallel.png", dpi=300)
plt.close()