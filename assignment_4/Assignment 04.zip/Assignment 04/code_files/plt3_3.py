import matplotlib.pyplot as plt
import numpy as np

lab_serial = np.mean([0.329618,0.333874,0.328261,0.332741,0.344608,0.326445,0.338068,0.347615,0.343665,0.324329])
lab_parallel = np.mean([0.026004,0.026361,0.025743,0.026831,0.025892,0.026174,0.026210,0.026173,0.026260,0.026192])

cluster_serial = np.mean([0.256052,0.256377,0.255737,0.255913,0.255681,0.255780,0.258142,0.255668,0.255935,0.255824])
cluster_parallel = np.mean([0.086365,0.064827,0.064316,0.064300,0.064309,0.055590,0.053767,0.057070,0.057296,0.058277])

speedup_lab = lab_serial / lab_parallel
speedup_cluster = cluster_serial / cluster_parallel

labels = ["Lab PC", "HPC Cluster"]
speedups = [speedup_lab, speedup_cluster]

plt.figure(figsize=(6,5))
bars = plt.bar(labels, speedups)

plt.ylabel("Speedup (Tserial / Tparallel)")
plt.title("Parallel Mover Speedup")

for bar in bars:
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, height,
             f"{height:.2f}x",
             ha='center', va='bottom')

plt.grid(axis='y')
plt.tight_layout()
plt.savefig("mover_speedup.png", dpi=300)
plt.close()