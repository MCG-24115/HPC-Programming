#ifndef UTILS_H
#define UTILS_H
#include <time.h>
#include "init.h"
extern int GRID_X, GRID_Y, NX, NY;
extern int NUM_Points, Maxiter;
extern double dx, dy;
void interpolation(double *mesh_value, Points *points);
void mover_serial(Points *points, double deltaX, double deltaY);
void mover_parallel(Points *points, double deltaX, double deltaY);
void save_mesh(double *mesh_value);

#endif
