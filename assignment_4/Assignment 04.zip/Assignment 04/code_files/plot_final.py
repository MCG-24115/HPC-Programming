import matplotlib.pyplot as plt
import numpy as np

# Problem indices
problem_index = [1, 2, 3]

# FAKE example execution times (seconds)
lab_times = [3.58, 3.82, 8]       # Lab PC
hpc_times = [15, 18, 16]    # HPC Cluster

x = np.arange(len(problem_index))
width = 0.35

plt.figure(figsize=(8,5))

plt.bar(x - width/2, lab_times, width, label='Lab PC')
plt.bar(x + width/2, hpc_times, width, label='HPC Cluster')

plt.xlabel("Problem Index")
plt.ylabel("Execution Time (seconds)")
plt.title("Execution Time vs Problem Index")

plt.xticks(x, problem_index)
plt.legend()
plt.grid(axis='y', linestyle='--', alpha=0.6)

plt.tight_layout()
plt.savefig("execution_time_vs_problem_index.png", dpi=300)
