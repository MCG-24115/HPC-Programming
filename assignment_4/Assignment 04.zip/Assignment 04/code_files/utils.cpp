#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>
#include "utils.h"

// Interpolation (Serial Code)
void interpolation(double *mesh_value, Points *points)
{
    const int npoints = NUM_Points;
    const int gx = GRID_X;

    const double inv_dx = 1.0 / dx;
    const double inv_dy = 1.0 / dy;

    memset(mesh_value, 0, GRID_X * GRID_Y * sizeof(double));

    for (int p = 0; p < npoints; p++)
    {
        double x = points[p].x;
        double y = points[p].y;

        int i = (int)(x * inv_dx);
        int j = (int)(y * inv_dy);

        if (i >= NX) i = NX - 1;
        if (j >= NY) j = NY - 1;

        double xi  = (x - i * dx) * inv_dx;
        double eta = (y - j * dy) * inv_dy;

        int idx = j * gx + i;

        mesh_value[idx]           += (1-xi)*(1-eta);
        mesh_value[idx+1]         += xi*(1-eta);
        mesh_value[idx+gx]        += (1-xi)*eta;
        mesh_value[idx+gx+1]      += xi*eta;
    }
}
// Stochastic Mover (Serial Code) 
void mover_serial(Points *points, double deltaX, double deltaY)
{
    for (int i = 0; i < NUM_Points; i++)
    {
        double new_x, new_y;

        do
        {
            double rx = ((double)rand() / RAND_MAX) * 2.0 * deltaX - deltaX;
            double ry = ((double)rand() / RAND_MAX) * 2.0 * deltaY - deltaY;

            new_x = points[i].x + rx;
            new_y = points[i].y + ry;

        } while (new_x < 0.0 || new_x > 1.0 ||
                 new_y < 0.0 || new_y > 1.0);

        points[i].x = new_x;
        points[i].y = new_y;
    }
}

// Stochastic Mover (Parallel Code) 
void mover_parallel(Points *points, double deltaX, double deltaY)
{
    const int npoints = NUM_Points;

    #pragma omp parallel
    {
        unsigned int seed = 1234 + omp_get_thread_num();

        #pragma omp for schedule(static)
        for (int i = 0; i < npoints; i++)
        {
            double new_x, new_y;

            do
            {
                double rx = ((double)rand_r(&seed) / RAND_MAX) * 2.0 * deltaX - deltaX;
                double ry = ((double)rand_r(&seed) / RAND_MAX) * 2.0 * deltaY - deltaY;

                new_x = points[i].x + rx;
                new_y = points[i].y + ry;

            } while (new_x < 0.0 || new_x > 1.0 ||
                     new_y < 0.0 || new_y > 1.0);

            points[i].x = new_x;
            points[i].y = new_y;
        }
    }
}
// Write mesh to file
void save_mesh(double *mesh_value) {

    FILE *fd = fopen("Mesh.out", "w");
    if (!fd) {
        printf("Error creating Mesh.out\n");
        exit(1);
    }

    for (int i = 0; i < GRID_Y; i++) {
        for (int j = 0; j < GRID_X; j++) {
            fprintf(fd, "%lf ", mesh_value[i * GRID_X + j]);
        }
        fprintf(fd, "\n");
    }

    fclose(fd);
}