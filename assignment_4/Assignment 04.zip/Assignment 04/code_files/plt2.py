import matplotlib.pyplot as plt
import numpy as np

# Configurations
configs = ["NX=250\nNY=100", "NX=500\nNY=200", "NX=1000\nNY=400"]

# Total execution times
lab_times = [7.900919, 7.614972, 8.753646]
hpc_times = [25.28, 24.69, 25.65]

x = np.arange(len(configs))
width = 0.38

plt.figure(figsize=(8,5))

# Bars
bars1 = plt.bar(x - width/2, lab_times, width, label="Lab PC")
bars2 = plt.bar(x + width/2, hpc_times, width, label="HPC Cluster")

# Labels
plt.xlabel("Grid Configuration")
plt.ylabel("Total Interpolation Time (seconds)")
plt.title("Experiment 02: Total Execution Time Comparison")

plt.xticks(x, configs)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.legend()

# Annotate bar values
for bar in bars1:
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, height,
             f'{height:.2f}',
             ha='center', va='bottom', fontsize=9)

for bar in bars2:
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, height,
             f'{height:.2f}',
             ha='center', va='bottom', fontsize=9)

plt.tight_layout()

plt.savefig("exp2_barplot.png", dpi=300)
plt.close()