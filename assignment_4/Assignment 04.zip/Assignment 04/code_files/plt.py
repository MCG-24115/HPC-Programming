import matplotlib.pyplot as plt
import numpy as np

# Number of particles
points = np.array([100, 10000, 1000000, 100000000])

# ---------------- LAB PC DATA ----------------
lab_config1 = [0.000092, 0.000912, 0.086449, 7.908311]
lab_config2 = [0.000251, 0.000992, 0.085155, 8.280575]
lab_config3 = [0.000877, 0.002129, 0.138165, 13.322193]

# ---------------- CLUSTER DATA ----------------
# small epsilon used instead of 0 to allow log scale
cluster_config1 = [1e-6, 1e-6, 0.31, 22.53]
cluster_config2 = [1e-6, 1e-6, 0.25, 24.79]
cluster_config3 = [0.01, 0.01, 0.27, 24.76]

configs = [
    ("Configuration 1 (NX=250, NY=100)", lab_config1, cluster_config1, "config1_comparison.png"),
    ("Configuration 2 (NX=500, NY=200)", lab_config2, cluster_config2, "config2_comparison.png"),
    ("Configuration 3 (NX=1000, NY=400)", lab_config3, cluster_config3, "config3_comparison.png")
]

for title, lab, cluster, filename in configs:

    plt.figure(figsize=(7,5))

    plt.plot(points, lab, marker='o', linewidth=2, label="Lab PC")
    plt.plot(points, cluster, marker='s', linewidth=2, label="HPC Cluster")

    plt.xscale("log")
    plt.yscale("log")

    plt.xlabel("Number of Particles (log scale)")
    plt.ylabel("Execution Time (seconds, log scale)")
    plt.title(title)

    plt.grid(True, which="both", linestyle="--", linewidth=0.5)
    plt.legend()

    plt.tight_layout()
    plt.savefig(filename, dpi=300)
    plt.close()

print("Plots saved successfully.")