import matplotlib.pyplot as plt
import numpy as np

iterations = np.arange(1,11)

# Lab PC
lab_serial = [0.329618,0.333874,0.328261,0.332741,0.344608,0.326445,0.338068,0.347615,0.343665,0.324329]
lab_parallel = [0.026004,0.026361,0.025743,0.026831,0.025892,0.026174,0.026210,0.026173,0.026260,0.026192]

# HPC Cluster
cluster_serial = [0.256052,0.256377,0.255737,0.255913,0.255681,0.255780,0.258142,0.255668,0.255935,0.255824]
cluster_parallel = [0.086365,0.064827,0.064316,0.064300,0.064309,0.055590,0.053767,0.057070,0.057296,0.058277]


plt.figure(figsize=(8,5))

plt.plot(iterations, lab_serial, marker='o', linestyle='--', label="Lab Serial")
plt.plot(iterations, lab_parallel, marker='o', linestyle='-', label="Lab Parallel")

plt.plot(iterations, cluster_serial, marker='s', linestyle='--', label="Cluster Serial")
plt.plot(iterations, cluster_parallel, marker='s', linestyle='-', label="Cluster Parallel")

plt.xlabel("Iteration")
plt.ylabel("Mover Time (seconds)")
plt.title("Iteration-wise Serial vs Parallel Mover Execution Time")

plt.grid(True)
plt.legend()

plt.tight_layout()
plt.savefig("mover_serial_vs_parallel_iterations.png", dpi=300)
plt.close()