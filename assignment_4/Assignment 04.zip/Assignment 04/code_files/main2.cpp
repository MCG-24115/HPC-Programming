#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>

#include "init.h"
#include "utils.h"

// Global variables
int GRID_X, GRID_Y, NX, NY;
int NUM_Points, Maxiter;
double dx, dy;

int main() {

    NUM_Points = 100000000;
    Maxiter = 10;

    // Use same configurations as Experiment 01
    int NX_values[3] = {100, 200, 400};   // <-- replace with your actual configs
    int NY_values[3] = {100, 200, 400};   // <-- replace with your actual configs

    omp_set_num_threads(4);

    printf("Problem\tTotal Interpolation Time (s)\n");

    for (int config = 0; config < 3; config++) {

        NX = NX_values[config];
        NY = NY_values[config];

        GRID_X = NX + 1;
        GRID_Y = NY + 1;
        dx = 1.0 / NX;
        dy = 1.0 / NY;

        // Allocate memory
        double *mesh_value = (double *) calloc(GRID_X * GRID_Y, sizeof(double));
        Points *points = (Points *) calloc(NUM_Points, sizeof(Points));

        // Initialize particles ONCE
        initializepoints(points);

        double total_interp_time = 0.0;

        for (int iter = 0; iter < Maxiter; iter++) {

            clock_t start = clock();
            interpolation(mesh_value, points);
            clock_t end = clock();

            double interp_time =
                (double)(end - start) / CLOCKS_PER_SEC;

            total_interp_time += interp_time;
        }

        printf("%d\t%lf\n", config + 1, total_interp_time);

        free(mesh_value);
        free(points);
    }

    return 0;
}