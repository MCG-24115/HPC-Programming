#ifndef UTILS_H
#define UTILS_H

void matrix_multiplication(double** A, double** B, double** C, int N, int type);

/* Problem B-1 */
void transpose(double** m, double** mt, int N);
void transposed_matrix_multiplication(double** m1, double** mt, double** result, int N);

/* Problem C-1 */
void block_matrix_multiplication(double** m1, double** m2, double** result, int B, int N);

#endif
